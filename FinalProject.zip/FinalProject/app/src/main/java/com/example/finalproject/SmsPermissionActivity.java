package com.example.finalproject;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class SmsPermissionActivity extends AppCompatActivity {

    private Button requestPermissionButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sms_permission_activity);  // Ensure this layout exists

        requestPermissionButton = findViewById(R.id.request_permission_button);

        // Button click listener to check and request permission
        requestPermissionButton.setOnClickListener(v -> checkSmsPermission());
    }

    // Check for SEND_SMS permission
    private void checkSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            // Request SMS permission
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, 1);
        } else {
            // Permission already granted, proceed with sending SMS
            sendSmsNotification();
        }
    }

    // Handle the result of the permission request
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == 1) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission granted, proceed with sending SMS
                Toast.makeText(this, "Permission granted", Toast.LENGTH_SHORT).show();
                sendSmsNotification();
            } else {
                // Permission denied, show a message to the user
                Toast.makeText(this, "Permission denied", Toast.LENGTH_SHORT).show();
            }
        }
    }

    // Send SMS notification (stub for actual functionality)
    private void sendSmsNotification() {
        // Handle sending SMS notification here.
        // For example, you can use SmsManager to send an SMS:
        // SmsManager smsManager = SmsManager.getDefault();
        // smsManager.sendTextMessage(phoneNumber, null, message, null, null);
        Toast.makeText(this, "Sending SMS notification", Toast.LENGTH_SHORT).show();
    }
}
