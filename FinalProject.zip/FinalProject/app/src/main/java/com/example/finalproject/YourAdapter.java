package com.example.finalproject;

import android.database.Cursor;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class YourAdapter extends RecyclerView.Adapter<YourAdapter.ViewHolder> {

    private Cursor cursor;
    private DatabaseHelper dbHelper;

    public YourAdapter(Cursor cursor, DatabaseHelper dbHelper) {
        this.cursor = cursor;
        this.dbHelper = dbHelper;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.data_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        if (cursor.moveToPosition(position)) {
            String item = cursor.getString(cursor.getColumnIndexOrThrow("item"));
            int quantity = cursor.getInt(cursor.getColumnIndexOrThrow("quantity"));
            holder.itemName.setText(item);
            holder.itemQuantity.setText("Qty: " + quantity);
        }
    }

    @Override
    public int getItemCount() {
        return cursor.getCount();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView itemName, itemQuantity;

        ViewHolder(View itemView) {
            super(itemView);
            itemName = itemView.findViewById(R.id.textViewItem);
            itemQuantity = itemView.findViewById(R.id.textViewQuantity);
        }
    }
}
