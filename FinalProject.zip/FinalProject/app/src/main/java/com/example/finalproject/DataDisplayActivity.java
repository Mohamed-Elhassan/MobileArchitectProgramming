package com.example.finalproject;

import android.app.AlertDialog;
import android.database.Cursor;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.widget.LinearLayout;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.RecyclerView;

public class DataDisplayActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private Button addDataButton;
    private YourAdapter adapter;
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.data_display_activity);

        dbHelper = new DatabaseHelper(this);
        recyclerView = findViewById(R.id.data_grid);
        addDataButton = findViewById(R.id.add_data_button);
        recyclerView.setLayoutManager(new GridLayoutManager(this, 2));

        loadData();

        // Add Data Button Functionality
        addDataButton.setOnClickListener(v -> showAddDataDialog());

        // Swipe-to-delete functionality
        ItemTouchHelper itemTouchHelper = new ItemTouchHelper(new ItemTouchHelper.SimpleCallback(0, ItemTouchHelper.LEFT) {
            @Override
            public boolean onMove(RecyclerView recyclerView, RecyclerView.ViewHolder viewHolder, RecyclerView.ViewHolder target) {
                return false; // No drag-and-drop support
            }

            @Override
            public void onSwiped(RecyclerView.ViewHolder viewHolder, int direction) {
                int position = viewHolder.getAdapterPosition();
                deleteData(position);
            }
        });
        itemTouchHelper.attachToRecyclerView(recyclerView);

        // Long press to edit data
        recyclerView.addOnItemTouchListener(new RecyclerItemClickListener(this, recyclerView,
                new RecyclerItemClickListener.OnItemClickListener() {
                    @Override
                    public void onItemClick(View view, int position) {
                        showEditDialog(position); // Call the edit dialog on item click
                    }

                    @Override
                    public void onItemLongClick(View view, int position) {
                        // Handle long press if needed (currently unused)
                    }
                }
        ));
    }

    private void loadData() {
        Cursor cursor = dbHelper.getAllData();
        adapter = new YourAdapter(cursor, dbHelper);
        recyclerView.setAdapter(adapter);
    }

    private void deleteData(int position) {
        Cursor cursor = dbHelper.getAllData();
        if (cursor.moveToPosition(position)) {
            int id = cursor.getInt(cursor.getColumnIndexOrThrow("id"));
            boolean success = dbHelper.deleteData(id);
            if (success) {
                Toast.makeText(this, "Item deleted", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Failed to delete item", Toast.LENGTH_SHORT).show();
            }
            loadData(); // Refresh data
        }
        cursor.close();
    }

    private void showEditDialog(int position) {
        Cursor cursor = dbHelper.getAllData();
        if (cursor.moveToPosition(position)) {
            int id = cursor.getInt(cursor.getColumnIndexOrThrow("id"));
            String currentItem = cursor.getString(cursor.getColumnIndexOrThrow("item"));
            int currentQuantity = cursor.getInt(cursor.getColumnIndexOrThrow("quantity"));

            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setTitle("Edit Item");

            // Set up input fields
            EditText itemNameInput = new EditText(this);
            itemNameInput.setInputType(InputType.TYPE_CLASS_TEXT);
            itemNameInput.setText(currentItem);

            EditText itemQuantityInput = new EditText(this);
            itemQuantityInput.setInputType(InputType.TYPE_CLASS_NUMBER);
            itemQuantityInput.setText(String.valueOf(currentQuantity));

            builder.setView(itemNameInput);
            builder.setMessage("Update Item Details");
            builder.setView(itemQuantityInput);

            builder.setPositiveButton("Update", (dialog, which) -> {
                String newItem = itemNameInput.getText().toString();
                int newQuantity = Integer.parseInt(itemQuantityInput.getText().toString());
                boolean success = dbHelper.updateData(id, newItem, newQuantity);
                if (success) {
                    Toast.makeText(this, "Item updated", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(this, "Failed to update item", Toast.LENGTH_SHORT).show();
                }
                loadData(); // Refresh data
            });

            builder.setNegativeButton("Cancel", (dialog, which) -> dialog.dismiss());
            builder.show();
        }
        cursor.close();
    }

    private void showAddDataDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Add New Item");

        // Create a LinearLayout to hold the input fields
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(50, 40, 50, 10); // Add padding for better UI

        // Create input fields
        EditText itemNameInput = new EditText(this);
        itemNameInput.setInputType(InputType.TYPE_CLASS_TEXT);
        itemNameInput.setHint("Item Name");

        EditText itemQuantityInput = new EditText(this);
        itemQuantityInput.setInputType(InputType.TYPE_CLASS_NUMBER);
        itemQuantityInput.setHint("Quantity");

        // Add the input fields to the layout
        layout.addView(itemNameInput);
        layout.addView(itemQuantityInput);

        // Set the layout as the dialog's view
        builder.setView(layout);

        builder.setPositiveButton("Add", (dialog, which) -> {
            String newItem = itemNameInput.getText().toString().trim();
            String quantityStr = itemQuantityInput.getText().toString().trim();
            int newQuantity = quantityStr.isEmpty() ? 0 : Integer.parseInt(quantityStr);

            if (!newItem.isEmpty()) {
                boolean success = dbHelper.addData(newItem, newQuantity);
                if (success) {
                    Toast.makeText(this, "Item added", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(this, "Failed to add item", Toast.LENGTH_SHORT).show();
                }
                loadData(); // Refresh data
            } else {
                Toast.makeText(this, "Item name cannot be empty", Toast.LENGTH_SHORT).show();
            }
        });

        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.dismiss());
        builder.show();
    }}

