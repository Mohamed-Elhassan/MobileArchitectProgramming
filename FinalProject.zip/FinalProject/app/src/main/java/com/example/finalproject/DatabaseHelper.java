package com.example.finalproject;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "AppDatabase.db";
    private static final int DATABASE_VERSION = 1;

    // Table and Column Names
    private static final String USER_TABLE = "users";
    private static final String COL_USERNAME = "username";
    private static final String COL_PASSWORD = "password";

    private static final String DATA_TABLE = "data";
    private static final String COL_ID = "id";
    private static final String COL_ITEM = "item";
    private static final String COL_QUANTITY = "quantity";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create Users Table
        String createUserTable = "CREATE TABLE " + USER_TABLE + " (" +
                COL_USERNAME + " TEXT PRIMARY KEY, " +
                COL_PASSWORD + " TEXT)";
        db.execSQL(createUserTable);

        // Create Data Table
        String createDataTable = "CREATE TABLE " + DATA_TABLE + " (" +
                COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_ITEM + " TEXT, " +
                COL_QUANTITY + " INTEGER)";
        db.execSQL(createDataTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Drop tables if they exist and recreate
        db.execSQL("DROP TABLE IF EXISTS " + USER_TABLE);
        db.execSQL("DROP TABLE IF EXISTS " + DATA_TABLE);
        onCreate(db);
    }

    // User Management Methods

    /**
     * Add a new user to the database.
     */
    public boolean addUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_USERNAME, username);
        values.put(COL_PASSWORD, password);
        long result = db.insert(USER_TABLE, null, values);
        db.close();
        return result != -1;
    }

    /**
     * Validate a user's credentials.
     */
    public boolean validateUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + USER_TABLE +
                        " WHERE " + COL_USERNAME + "=? AND " + COL_PASSWORD + "=?",
                new String[]{username, password});
        boolean exists = cursor.getCount() > 0;
        cursor.close();
        db.close();
        return exists;
    }

    // Data Management Methods

    /**
     * Add a new data item to the database.
     */
    public boolean addData(String item, int quantity) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_ITEM, item);
        values.put(COL_QUANTITY, quantity);
        long result = db.insert(DATA_TABLE, null, values);
        db.close();
        return result != -1;
    }

    /**
     * Retrieve all data items from the database.
     */
    public Cursor getAllData() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + DATA_TABLE, null);
    }

    /**
     * Update an existing data item in the database.
     */
    public boolean updateData(int id, String item, int quantity) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_ITEM, item);
        values.put(COL_QUANTITY, quantity);
        int rowsUpdated = db.update(DATA_TABLE, values, COL_ID + "=?", new String[]{String.valueOf(id)});
        db.close();
        return rowsUpdated > 0;
    }

    /**
     * Delete a data item from the database by ID.
     */
    public boolean deleteData(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        int rowsDeleted = db.delete(DATA_TABLE, COL_ID + "=?", new String[]{String.valueOf(id)});
        db.close();
        return rowsDeleted > 0;
    }
}
